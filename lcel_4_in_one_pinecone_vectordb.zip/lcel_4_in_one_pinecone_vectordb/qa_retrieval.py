
from langchain_core.runnables import  RunnablePassthrough, RunnableParallel
from langchain.prompts import ChatPromptTemplate
from langchain.chat_models import ChatOpenAI
import os
from langchain_core.output_parsers import StrOutputParser
from langchain_google_genai import GoogleGenerativeAIEmbeddings, ChatGoogleGenerativeAI
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain.embeddings import HuggingFaceEmbeddings
import openai
from pinecone import Pinecone, ServerlessSpec
from dotenv import  load_dotenv
from langchain_pinecone import PineconeVectorStore
from langchain.vectorstores import Pinecone
from pinecone import Pinecone, ServerlessSpec
from dotenv import  load_dotenv
import os 
load_dotenv()

key=os.getenv("PINECONE_API_KEY")

pc = Pinecone(api_key=key)

# GOOGLE_API_KEY ="AIzaSyDG62pWDrJzureZLLSidRMqkc11dqXr1Zc"

embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
index_name = "testing-pinecone-first"

text_field = "text"

# switch back to normal index for langchain
index = pc.Index(index_name)
vectorstore = PineconeVectorStore(
    index, embeddings,text_field)

def qa_ret(vectorstore,input_query):
    try:
        template = """You are AI assistant that assisant user by providing answer to the question of user by extracting information from provided context:
        {context} and chat_history if user question is related to chat_history take chat history as context .
        if you donot find any relevant information from context for given question just say ask me another quuestion. you are ai assistant.
        Answer should not be greater than 3 lines.
        Question: {question}
        """

        prompt = ChatPromptTemplate.from_template(template)
        retriever= vectorstore.as_retriever(search_type="similarity", search_kwargs={"k": 2})
        setup_and_retrieval = RunnableParallel(
                {"context": retriever, "question": RunnablePassthrough()}
                )
            # Load QA Chain
        GOOGLE_API_KEY ="AIzaSyDG62pWDrJzureZLLSidRMqkc11dqXr1Zc"
        model = ChatGoogleGenerativeAI(model="gemini-pro", temperature=0.3,google_api_key = GOOGLE_API_KEY)
        output_parser= StrOutputParser()
        rag_chain = (
        setup_and_retrieval
        | prompt
        | model
        | output_parser
        )
        respone=rag_chain.invoke(input_query)
        return respone
    except Exception as ex:
        return ex
    
def qa_retrieval(input_query):
        result = qa_ret(vectorstore,input_query)
        return result

# input_query = "is xeven working on ai and ml"
# final = qa_ret(vectorstore,input_query)

# print(final)