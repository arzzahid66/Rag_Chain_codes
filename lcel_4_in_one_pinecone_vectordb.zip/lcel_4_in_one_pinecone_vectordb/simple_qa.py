
import langchain 
from langchain_google_genai import GoogleGenerativeAIEmbeddings, ChatGoogleGenerativeAI
from langchain.prompts import ChatPromptTemplate
from langchain.schema.output_parser import StrOutputParser
import os 
from langchain_core.runnables import  RunnablePassthrough, RunnableParallel

# import getpass
# import os
# from openai import OpenAI
# client = OpenAI()

GOOGLE_API_KEY ="AIzaSyDG62pWDrJzureZLLSidRMqkc11dqXr1Zc"
# OPEN_AI_KEY = "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"
# MISTRAL_API_KEY = "VlnWH8WSkaRqdP3M5ACU3PF61I2NsxTO"
api_key = GOOGLE_API_KEY
# open_api_key = OPEN_AI_KEY     


def rag(input_query):
    try:
        template = """Hello! I'm your AI assistant here to help. Feel free to ask me anything, and I'll provide polite, concise answers. :
        Question: {question}
        """
        prompt = ChatPromptTemplate.from_template(template)
        setup_and_retrieval = RunnableParallel(
        {"question": RunnablePassthrough()}
                )
        model = ChatGoogleGenerativeAI(model="gemini-pro", temperature=0.3, google_api_key =api_key)
        output_parser = StrOutputParser()
        rag_chain = (
        setup_and_retrieval
        | prompt
        | model
        | output_parser
        )
       
        response= rag_chain.invoke(input_query)

        return response
    except Exception as ex:
        return ex

# res = rag(input_query)
# print(res)