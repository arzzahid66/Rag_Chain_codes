from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationalRetrievalChain
from langchain_core.output_parsers import StrOutputParser
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.prompts import PromptTemplate
from langchain.memory import ConversationBufferMemory
import psycopg2
import openai
from sqlalchemy import create_engine
from langchain_community.utilities import SQLDatabase
from langchain_openai import ChatOpenAI
from langchain_community.tools.sql_database.tool import QuerySQLDataBaseTool
from operator import itemgetter
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import PromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain.chains import ConversationChain
from langchain_core.messages import HumanMessage, AIMessage
from langchain.chat_models import ChatOpenAI

# GOOGLE_API_KEY ="AIzaSyDG62pWDrJzureZLLSidRMqkc11dqXr1Zc"
# api_key = GOOGLE_API_KEY

openai_api_key = "sk-proj-qd1OBuKlyCMxyfTjloXAT3BlbkFJmdakmCYrg4XxBqttZaun"
OPENAI_API_KEY = openai_api_key


# chat_history = [HumanMessage(content='question'),
#   AIMessage(content='answer'),
#   HumanMessage(content='question'),
#   AIMessage(content="answer")]

def simple_conversational_chain(input_query):
    try :
        custom_template = """Following is a conversation between human and AI. Use history as context. Generate freidnly responses to user input.
                            Chat History:
                            {history}
                            Follow-Up Input: {input}
                            Standalone question:"""
        CUSTOM_QUESTION_PROMPT = PromptTemplate.from_template(custom_template)
        llm = ChatOpenAI(model = "gpt-3.5-turbo-16k", openai_api_key = OPENAI_API_KEY, temperature=0.3,max_tokens=50)
        conversational_chain = ConversationChain(
            prompt=CUSTOM_QUESTION_PROMPT,
            memory = ConversationBufferMemory(),
            llm=llm,
            # retriever = vector_db.as_retriever(),
            verbose = True
        )
        response = conversational_chain.invoke(input_query)

        return response
    except Exception as ex:
        return ex






