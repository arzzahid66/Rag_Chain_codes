from typing import Union
from fastapi import FastAPI , Response , status
from fastapi.responses import JSONResponse
from qa_retrieval import *
from fastapi import APIRouter , status , Depends, Request


router =APIRouter()

@router.post("/posts/QA Retrieval/{input_query}")
def get_QA(input_query):
    try :
        result = qa_retrieval(input_query)
        
        return JSONResponse({"here is response :":result})
    
    except Exception as ex:
        ex


# from qdrant_client import QdrantClient
# from langchain_core.runnables import  RunnablePassthrough, RunnableParallel
# from langchain.prompts import ChatPromptTemplate
# from langchain.chat_models import ChatOpenAI
# import os
# from langchain_core.output_parsers import StrOutputParser
# from langchain_google_genai import GoogleGenerativeAIEmbeddings, ChatGoogleGenerativeAI
# from langchain_text_splitters import RecursiveCharacterTextSplitter
# from langchain.embeddings import HuggingFaceEmbeddings
# from langchain_community.vectorstores import Qdrant

# GOOGLE_API_KEY ="AIzaSyDG62pWDrJzureZLLSidRMqkc11dqXr1Zc"
# api_key = GOOGLE_API_KEY

# from qdrant_client import QdrantClient
# from pinecone import Pinecone, ServerlessSpec
# from dotenv import  load_dotenv
# import os 
# from langchain_pinecone import PineconeVectorStore
# from langchain.vectorstores import Pinecone
# from pinecone import Pinecone, ServerlessSpec
# from dotenv import  load_dotenv
# load_dotenv()

# key=os.getenv("PINECONE_API_KEY")

# pc = Pinecone(api_key=key)
# embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
# index_name = "testing-pinecone-first"

# from langchain.vectorstores import Pinecone

# text_field = "text"

# # switch back to normal index for langchain
# index = pc.Index(index_name)

# vectorstore = PineconeVectorStore(
#     index, embeddings, text_field)



# def qa_ret(vectorstore,input_query):
#     try:
#         template = """You are AI assistant that assisant user by providing answer to the question of user by extracting information from provided context:
#         {context} and chat_history if user question is related to chat_history take chat history as context .
#         if you donot find any relevant information from context for given question just say ask me another quuestion. you are ai assistant.
#         Answer should not be greater than 3 lines.
#         Question: {question}
#         """

#         prompt = ChatPromptTemplate.from_template(template)
#         retriever= vectorstore.as_retriever(search_type="similarity", search_kwargs={"k": 2})
#         setup_and_retrieval = RunnableParallel(
#                 {"context": retriever, "question": RunnablePassthrough()}
#                 )
#             # Load QA Chain
#         model = ChatGoogleGenerativeAI(model="gemini-pro", temperature=0.3,google_api_key =api_key)
#         output_parser= StrOutputParser()
#         rag_chain = (
#         setup_and_retrieval
#         | prompt
#         | model
#         | output_parser
#         )
#         respone=rag_chain.invoke(input_query)
#         return respone
#     except Exception as ex:
#         return ex


# def qa_retrieval(input_query):
#         result = qa_ret(vectorstore,input_query)
#         return result
