from fastapi import FastAPI, File, UploadFile
from fastapi.responses import HTMLResponse
from fastapi import APIRouter , status , Depends, Request
from fastapi.responses import JSONResponse
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader
from fastapi import FastAPI, File, UploadFile, APIRouter
from pydantic import BaseModel
from io import BytesIO
from dotenv import  load_dotenv
load_dotenv()
from langchain_core.documents import Document
import os 
from fastapi import FastAPI, File, UploadFile , HTTPException
import tempfile
app = FastAPI()
router =APIRouter()
from pinecone import Pinecone, ServerlessSpec
from langchain.embeddings import HuggingFaceEmbeddings
from langchain_pinecone import PineconeVectorStore
from dotenv import  load_dotenv
import os 
load_dotenv()

key=os.getenv("PINECONE_API_KEY")

pc = Pinecone(api_key=key)

def read_doc(file_path):
    # Initialize PyPDFLoader with the file path
    file_loader = PyPDFLoader(file_path)
    documents = file_loader.load()
    return documents

def split_doc(read):
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=700,
        chunk_overlap=70,
        length_function=len,
        is_separator_regex=False,
    )
    texts = text_splitter.split_documents(read)
    return texts

# insertion in pinecone 
def pinecone_setup(index_name):
    if index_name not in pc.list_indexes().names():
        pc.create_index(
            name=index_name,
            dimension=384,
            metric="cosine",
            spec=ServerlessSpec(
                cloud='aws', 
                region='us-east-1'
            ) 
        )

def vector_insertion(documents,embeddings,index_name):
    print(documents)
    try:
        doc_search=PineconeVectorStore.from_documents(
            documents,
            embedding=embeddings,
            index_name=index_name,
            )
        return doc_search
    except Exception as e:
        return e

@router.post("/uploadfile/")
async def upload_file(file: UploadFile = File(...)):
    try:
        # Create a temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as temp_file:
            temp_file.write(await file.read())
            temp_file_path = temp_file.name
        
        # Process the temporary file with read_doc function
        read = read_doc(temp_file_path)
        chunk = split_doc(read)
        chunks_no = len(chunk)
        documents = [Document(doc.page_content, metadata={"source": "abd"}) for doc in chunk]
        embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")

        index_name="xevensolution-new"
        pinecone_setup(index_name)
        
        # index = pc.Index(index_name)
        vector_insertion(documents,embeddings,index_name)
        final_result = "file uploaded"
        
        # Clean up the temporary file
        os.remove(temp_file_path)
        
        return {"filename": file.filename, "content_type": file.content_type,"chunks_no": chunks_no,"final_result":final_result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))







    






