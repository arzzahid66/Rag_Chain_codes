from typing import Union
from fastapi import FastAPI , Response , status
from fastapi.responses import JSONResponse
from coversa_chain import *
from fastapi import APIRouter , status , Depends, Request


router = APIRouter()


@router.post("/posts/conversational_chain/{input_query}")
def get_QA(input_query):
    try :
        result = simple_conversational_chain(input_query)
        
        return JSONResponse({"here is response :":result})
    
    except Exception as ex:
        ex