
from typing import Union
from fastapi import FastAPI , Response , status
from fastapi.responses import JSONResponse
from simple_qa import*
from fastapi import APIRouter , status , Depends, Request


router =APIRouter()

@router.post("/posts/QA/{input_query}")
def get_QA(input_query):
    try :
        result = rag(input_query)
        
        return JSONResponse({"here is response :":result})
    
    except Exception as ex:
        ex
